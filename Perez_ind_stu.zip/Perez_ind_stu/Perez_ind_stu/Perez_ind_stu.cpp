// Perez_ind_stu.cpp : This file contains the 'main' function. Program execution begins and ends there.
//Romary Perez Independent Study JAN 31, 2019

#include "pch.h"
#include <iostream>
#include <string>

using namespace std;

int main()
{
    string name;
	int age;

	cout << "Enter your name:";
	cin >> name;
	cout << endl;

	cout << "Enter your age:";
	cin >> age;
	cout << endl;

	cout << "name: " << name << endl;
	cout << "age: " << age << endl;

	return 0;
}

