// Perez_Factorial_2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <string>
using namespace std;

int main()
{
	int a;
	int f = 1;

	cout << "Enter an integer: ";
	cin >> a;

	for (int s = 1, s <= n;);
	{
		f = f * s;
	}

	cout << "Factorial is: " <<f;
	

